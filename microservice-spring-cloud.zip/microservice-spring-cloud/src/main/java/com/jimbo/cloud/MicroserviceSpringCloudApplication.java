package com.jimbo.cloud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroserviceSpringCloudApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroserviceSpringCloudApplication.class, args);
	}
}
